package deploycheck

import (
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"
)

// Deployment is an intentionally narrow Kubernetes apps/v1 Deployment model.
// Unknown fields are rejected to prevent an admission bypass through unexamined configuration.
type Deployment struct {
	APIVersion string `json:"apiVersion"`
	Kind       string `json:"kind"`
	Metadata   struct {
		Name      string `json:"name"`
		Namespace string `json:"namespace"`
	} `json:"metadata"`
	Spec struct {
		Replicas *int `json:"replicas"`
		Selector struct {
			MatchLabels map[string]string `json:"matchLabels"`
		} `json:"selector"`
		Template struct {
			Metadata struct {
				Labels map[string]string `json:"labels"`
			} `json:"metadata"`
			Spec struct {
				AutomountServiceAccountToken *bool  `json:"automountServiceAccountToken"`
				HostNetwork                  bool   `json:"hostNetwork"`
				HostPID                      bool   `json:"hostPID"`
				HostIPC                      bool   `json:"hostIPC"`
				ServiceAccountName           string `json:"serviceAccountName"`
				SecurityContext              struct {
					RunAsNonRoot   *bool `json:"runAsNonRoot"`
					SeccompProfile struct {
						Type string `json:"type"`
					} `json:"seccompProfile"`
				} `json:"securityContext"`
				Containers []struct {
					Name            string `json:"name"`
					Image           string `json:"image"`
					SecurityContext struct {
						Privileged               bool  `json:"privileged"`
						AllowPrivilegeEscalation *bool `json:"allowPrivilegeEscalation"`
						ReadOnlyRootFilesystem   *bool `json:"readOnlyRootFilesystem"`
						Capabilities             struct {
							Drop []string `json:"drop"`
							Add  []string `json:"add"`
						} `json:"capabilities"`
					} `json:"securityContext"`
				} `json:"containers"`
				InitContainers      []json.RawMessage `json:"initContainers"`
				EphemeralContainers []json.RawMessage `json:"ephemeralContainers"`
				Volumes             []json.RawMessage `json:"volumes"`
			} `json:"spec"`
		} `json:"template"`
	} `json:"spec"`
}

var digest = regexp.MustCompile(`^[a-f0-9]{64}$`)

// Check validates a restricted single-container Deployment against a trusted observed
// OCI image digest. It is a preflight contract, not Kubernetes admission enforcement.
func Check(data []byte, namespace, expectedDigest string) error {
	if !digest.MatchString(expectedDigest) {
		return errors.New("invalid trusted image digest")
	}
	var d Deployment
	dec := json.NewDecoder(strings.NewReader(string(data)))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&d); err != nil {
		return fmt.Errorf("malformed or unsupported deployment: %w", err)
	}
	var extra any
	if err := dec.Decode(&extra); err == nil {
		return errors.New("multiple JSON documents denied")
	} else if err.Error() != "EOF" {
		return fmt.Errorf("trailing JSON: %w", err)
	}
	if d.APIVersion != "apps/v1" || d.Kind != "Deployment" || d.Metadata.Namespace != namespace || namespace == "" || d.Metadata.Name == "" {
		return errors.New("resource identity denied")
	}
	if d.Spec.Replicas == nil || *d.Spec.Replicas < 1 || *d.Spec.Replicas > 10 {
		return errors.New("replicas denied")
	}
	p := d.Spec.Template.Spec
	if p.AutomountServiceAccountToken == nil || *p.AutomountServiceAccountToken || p.HostNetwork || p.HostPID || p.HostIPC || p.ServiceAccountName != "" {
		return errors.New("pod privileges denied")
	}
	if p.SecurityContext.RunAsNonRoot == nil || !*p.SecurityContext.RunAsNonRoot || p.SecurityContext.SeccompProfile.Type != "RuntimeDefault" {
		return errors.New("pod security context denied")
	}
	if len(p.Containers) != 1 || len(p.InitContainers) != 0 || len(p.EphemeralContainers) != 0 || len(p.Volumes) != 0 {
		return errors.New("additional execution or mounts denied")
	}
	c := p.Containers[0]
	if c.Name == "" || c.SecurityContext.Privileged || c.SecurityContext.AllowPrivilegeEscalation == nil || *c.SecurityContext.AllowPrivilegeEscalation || c.SecurityContext.ReadOnlyRootFilesystem == nil || !*c.SecurityContext.ReadOnlyRootFilesystem || len(c.SecurityContext.Capabilities.Add) != 0 {
		return errors.New("container privileges denied")
	}
	if len(c.SecurityContext.Capabilities.Drop) != 1 || c.SecurityContext.Capabilities.Drop[0] != "ALL" {
		return errors.New("capabilities must drop ALL")
	}
	parts := strings.Split(c.Image, "@sha256:")
	if len(parts) != 2 || parts[0] == "" || strings.Contains(parts[0], " ") || parts[1] != expectedDigest {
		return errors.New("image digest mismatch or mutable tag")
	}
	if len(d.Spec.Selector.MatchLabels) == 0 {
		return errors.New("missing workload selector")
	}
	for k, v := range d.Spec.Selector.MatchLabels {
		if d.Spec.Template.Metadata.Labels[k] != v {
			return errors.New("selector mismatch")
		}
	}
	return nil
}
