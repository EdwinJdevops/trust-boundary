# Trust Boundary — Go release-authority experiment 010

This is an experimental authorization core, **not a deployable production control plane**. It extends the Python Experiment 009 as a separate module rather than silently replacing it.

## Verified contract

- Ed25519 signature on a fixed JSON intent schema; issuer private key is not needed by verifier.
- Exact SHA-256 artifact digest, issuer, workload, target environment, operation, expiry and nonce matching.
- Fail-closed single-use local replay record using atomic exclusive file creation and filesystem sync.
- No dependencies outside Go's standard library.

## Test

`go test -race -count=1 ./...`

## Trust assumptions and current blockers

1. The `observedDigest` argument MUST be supplied by a separate trusted executor measuring real bytes. Passing an attacker-supplied value destroys artifact binding.
2. Only a private, locally controlled replay directory is supported. Filesystem durability semantics depend on filesystem/platform; NFS/distributed execution is outside scope. The verifier does not securely establish the owner of the directory or prevent a privileged adversary from altering it.
3. Recording authorization is not the same as recording successful deployment. This module doesn't execute cluster changes or recover external mutations.
4. There is no trusted launcher, no proven isolation, no SPIFFE identity, no Kubernetes adapter, no signing-key lifecycle, no audited event storage, and no protected remote protocol.
5. A local caller using a trusted executor's identity might still request authorization: real authentication, workload attestation and OS separation must be tested.
6. The verifier is suitable for engineering research and CI tests, not production authorization.

## Launch gates

A public engineering preview must clearly identify these limits. A production release must additionally demonstrate independent OS identities, confined executor, strict network policies, protected keys, trusted artifact measurement, Kubernetes mutation restrictions, state reconciliation, telemetry, and adversarial testing under real Linux isolation.

## Experiment 011 — Restricted Kubernetes Deployment JSON contract

Package `deploycheck` validates a deliberately narrow `apps/v1` Deployment JSON document before it can be submitted to a trusted executor. It refuses unknown fields, multiple containers, init containers, volumes, privileged execution, service-account-token mounts, host networking/PID/IPC, image tags, altered image digests, and wrong namespaces. Positive test: a restricted digest-pinned single-container workload with a non-root profile, no escalation, read-only root filesystem, dropped capabilities, RuntimeDefault seccomp, and matching selectors.

Run `go test -race -count=1 ./...` and `go vet ./...` from this directory. The new contract has 11 table-driven cases; the pre-existing `gate` suite is retained.

**Limitations (security critical):** This checks JSON supplied to this function, not the image actually running in Kubernetes. The digest must be independently measured and provided by a trusted executor. There is no Kubernetes client, RBAC, admission webhook, protected namespace, authentication, sandbox containment, policy distribution, or deployment reconciliation. Direct cluster access bypasses this library. This allowlist is intentionally restrictive and does not validate every Kubernetes default or mutating admission behavior. Treat it as an experimental preflight guard only. Do not use it as the sole deployment security control.
