"""Pure contract checks: runnable without Bubblewrap or root permissions."""
import json
import tempfile
from artifact_gate import digest, enforce_pinned_artifact
import unittest
from pathlib import Path


class ExperimentContractTests(unittest.TestCase):
    def test_exact_pinned_artifact_accepted(self):
        with tempfile.TemporaryDirectory() as temp:
            artifact = Path(temp) / 'tool.py'
            artifact.write_bytes(b'print(42)\n')
            self.assertEqual(enforce_pinned_artifact(artifact, digest(artifact)), digest(artifact))

    def test_modified_artifact_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            artifact = Path(temp) / 'tool.py'
            artifact.write_bytes(b'print(42)\n')
            pinned = digest(artifact)
            artifact.write_bytes(b'print(43)\n')
            with self.assertRaisesRegex(ValueError, 'execution denied'):
                enforce_pinned_artifact(artifact, pinned)

    def test_invalid_hash_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            artifact = Path(temp) / 'tool.py'
            artifact.write_bytes(b'print(42)\n')
            with self.assertRaises(ValueError):
                enforce_pinned_artifact(artifact, 'incorrect')

    def test_probe_parses(self):
        import ast
        ast.parse(Path(__file__).with_name('probe.py').read_text())

    def test_runner_parses(self):
        import ast
        ast.parse(Path(__file__).with_name('experiment.py').read_text())

    def test_probe_has_no_network_destination_literal(self):
        source = Path(__file__).with_name('probe.py').read_text()
        self.assertNotIn('https://', source)
        self.assertIn("os.environ['LAB_MOCK_URL']", source)

    def test_report_asserts_positive_and_negative_controls(self):
        source = Path(__file__).with_name('experiment.py').read_text()
        self.assertEqual(source.count("get('permitted_work_succeeds') is True"), 2)
        self.assertIn('baseline_ok and isolation_ok', source)


if __name__ == '__main__':
    unittest.main()
