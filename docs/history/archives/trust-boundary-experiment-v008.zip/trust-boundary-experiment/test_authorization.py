import unittest
from authorization import Broker, Denied, Request

SHA = 'a' * 64
ALLOW = {('read', 'mock://sandbox/metadata')}
REQ = Request(SHA, 'execution-001', 'read', 'mock://sandbox/metadata')


class AuthorizationTests(unittest.TestCase):
    def setUp(self):
        self.now = 100.0
        self.broker = Broker(ALLOW, ttl_seconds=10, clock=lambda: self.now)

    def test_permitted_single_use(self):
        grant = self.broker.issue(REQ)
        self.assertTrue(self.broker.consume(grant, REQ)['authorized'])
        with self.assertRaises(Denied):
            self.broker.consume(grant, REQ)

    def test_policy_default_deny(self):
        with self.assertRaises(Denied):
            self.broker.issue(Request(SHA, 'execution-001', 'delete', 'mock://production'))

    def test_artifact_substitution_denied(self):
        grant = self.broker.issue(REQ)
        with self.assertRaises(Denied):
            self.broker.consume(grant, Request('b' * 64, REQ.execution_id, REQ.operation, REQ.resource))
        with self.assertRaises(Denied):
            self.broker.consume(grant, REQ)

    def test_execution_switch_denied(self):
        grant = self.broker.issue(REQ)
        with self.assertRaises(Denied):
            self.broker.consume(grant, Request(SHA, 'execution-002', REQ.operation, REQ.resource))

    def test_resource_switch_denied(self):
        grant = self.broker.issue(REQ)
        with self.assertRaises(Denied):
            self.broker.consume(grant, Request(SHA, REQ.execution_id, REQ.operation, 'mock://production'))

    def test_expiry_denied(self):
        grant = self.broker.issue(REQ)
        self.now += 10
        with self.assertRaises(Denied):
            self.broker.consume(grant, REQ)

    def test_invalid_identity_denied(self):
        with self.assertRaises(Denied):
            self.broker.issue(Request('bad', REQ.execution_id, REQ.operation, REQ.resource))

    def test_audit_contains_no_grant_token(self):
        token = self.broker.issue(REQ)
        self.broker.consume(token, REQ)
        self.assertNotIn(token, str(self.broker.events()))
        self.assertEqual(len(self.broker.audit_sha256()), 64)

    def test_invalid_ttl_rejected(self):
        for ttl in (0, 301):
            with self.assertRaises(ValueError):
                Broker(ALLOW, ttl)


if __name__ == '__main__':
    unittest.main()
