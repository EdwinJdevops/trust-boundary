"""Synthetic client, running as separate process; no cloud credentials."""
import json
import os
import sys
from boundary_service import request


def main():
    # Wait until privileged test harness has registered this exact PID.
    fd = int(os.environ['BOUNDARY_READY_FD'])
    signal = os.read(fd, 1)
    os.close(fd)
    if signal != b'1':
        raise SystemExit('launcher aborted')
    outcome = request(sys.argv[1], sys.argv[2], sys.argv[3])
    print(json.dumps(outcome, sort_keys=True))
    return 0 if outcome['ok'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
