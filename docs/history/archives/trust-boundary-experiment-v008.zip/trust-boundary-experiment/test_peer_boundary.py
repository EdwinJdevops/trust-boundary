import os
import socket
import sys
import unittest
from unittest.mock import patch
from peer_boundary import PeerRegistry, PeerDenied, linux_process_start_ticks

@unittest.skipUnless(sys.platform.startswith('linux') and hasattr(socket, 'SO_PEERCRED'), 'Linux-only')
class PeerBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.registry = PeerRegistry()
        self.a, self.b = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)

    def tearDown(self):
        self.a.close()
        self.b.close()

    def test_unregistered_peer_denied(self):
        with self.assertRaises(PeerDenied):
            self.registry.authenticate(self.a)

    def test_registered_peer_authenticated_from_kernel(self):
        self.registry.register(os.getpid(), os.getuid(), 'a'*64, 'execution-one')
        result = self.registry.authenticate(self.a)
        self.assertEqual(result.pid, os.getpid())
        self.assertEqual(result.execution_id, 'execution-one')

    def test_revocation_immediate(self):
        self.registry.register(os.getpid(), os.getuid(), 'a'*64, 'execution-one')
        self.registry.revoke(os.getpid())
        with self.assertRaises(PeerDenied):
            self.registry.authenticate(self.a)

    def test_pid_reuse_or_start_change_denied(self):
        self.registry.register(os.getpid(), os.getuid(), 'a'*64, 'execution-one')
        with patch('peer_boundary.linux_process_start_ticks', return_value=linux_process_start_ticks(os.getpid())+1):
            with self.assertRaises(PeerDenied):
                self.registry.authenticate(self.a)

    def test_bad_artifact_rejected(self):
        with self.assertRaises(ValueError):
            self.registry.register(os.getpid(), os.getuid(), 'not-a-digest', 'execution-one')

if __name__ == '__main__':
    unittest.main()
