"""Safe offline simulation: no network connections or infrastructure credentials."""
import json
from artifact_gate import digest
from authorization import Broker, Denied, Request
from pathlib import Path


def main():
    artifact = Path(__file__).with_name('probe.py')
    identity = digest(artifact)
    broker = Broker({('read', 'mock://sandbox/metadata')})
    approved = Request(identity, 'local-test-001', 'read', 'mock://sandbox/metadata')
    token = broker.issue(approved)
    result = broker.consume(token, approved)
    try:
        broker.issue(Request(identity, 'local-test-001', 'withdraw', 'mock://production/funds'))
    except Denied:
        denied = True
    else:
        denied = False
    print(json.dumps({'approved': result['authorized'], 'production_operation_denied': denied,
                      'events': broker.events(), 'audit_sha256': broker.audit_sha256()}, indent=2))
    return 0 if result['authorized'] and denied else 1


if __name__ == '__main__':
    raise SystemExit(main())
