#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
cd "$(dirname "$0")"
mkdir -p evidence
out="evidence/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$out"
sha256sum experiment.py probe.py preflight.py test_contract.py test_authorization.py authorization.py demo_authorization.py artifact_gate.py > "$out/source-sha256.txt"
set +e
python3 preflight.py > "$out/preflight.json"
preflight_status=$?
python3 -m unittest -v test_contract.py test_authorization.py > "$out/unit-tests.log" 2>&1
unit_status=$?
set -e
if (( preflight_status != 0 || unit_status != 0 )); then
  printf 'Preflight or unit tests failed; experiment not run. Evidence: %s\n' "$out" >&2
  exit 2
fi
set +e
timeout 45s python3 experiment.py > "$out/experiment.json" 2> "$out/experiment.stderr"
experiment_status=$?
set -e
printf '%s\n' "$experiment_status" > "$out/experiment-exit-status.txt"
if (( experiment_status != 0 )); then
  printf 'Experiment did not pass. Evidence: %s\n' "$out" >&2
  exit 1
fi
python3 - "$out/experiment.json" <<'PY'
import json, sys
from pathlib import Path
p=Path(sys.argv[1]); report=json.loads(p.read_text())
assert report['baseline_demonstrates_exposure'] is True
assert report['isolation_checks_pass'] is True
print('Functional boundary assertions passed. Not a sandbox security certification.')
PY
printf 'Evidence: %s\n' "$out"
