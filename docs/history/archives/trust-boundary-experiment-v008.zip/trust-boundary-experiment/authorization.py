"""Offline, synthetic authorization state machine. Not a cloud credential broker."""
from dataclasses import dataclass
import hashlib
import hmac
import json
import secrets
import time


class Denied(Exception):
    pass


@dataclass(frozen=True)
class Request:
    artifact_sha256: str
    execution_id: str
    operation: str
    resource: str


class Broker:
    """In-memory admission and consumption; single process, no distributed guarantees."""

    def __init__(self, allowed: set[tuple[str, str]], ttl_seconds: int = 30, clock=None):
        if not (1 <= ttl_seconds <= 300):
            raise ValueError('TTL must be between 1 and 300 seconds')
        self._allowed = frozenset(allowed)
        self._ttl = ttl_seconds
        self._clock = clock if clock is not None else time.monotonic
        self._pending = {}
        self._audit = []

    @staticmethod
    def _validate(req: Request):
        if (len(req.artifact_sha256) != 64 or
                any(c not in '0123456789abcdef' for c in req.artifact_sha256)):
            raise Denied('invalid artifact identity')
        if not req.execution_id or len(req.execution_id) > 128:
            raise Denied('invalid execution identity')
        if not req.operation or not req.resource:
            raise Denied('operation and resource required')

    def _record(self, event: str, req: Request):
        self._audit.append({'event': event, 'artifact_sha256': req.artifact_sha256,
                            'execution_id': req.execution_id,
                            'operation': req.operation, 'resource': req.resource})

    def issue(self, req: Request) -> str:
        self._validate(req)
        if (req.operation, req.resource) not in self._allowed:
            self._record('policy_denied', req)
            raise Denied('operation not permitted by policy')
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode('ascii')).digest()
        self._pending[token_hash] = (req, self._clock() + self._ttl)
        self._record('grant_issued', req)
        return token

    def consume(self, token: str, req: Request) -> dict:
        self._validate(req)
        if not isinstance(token, str) or not token:
            self._record('invalid_grant', req)
            raise Denied('invalid grant')
        token_hash = hashlib.sha256(token.encode('utf-8')).digest()
        entry = self._pending.pop(token_hash, None)
        if entry is None:
            self._record('invalid_or_replayed_grant', req)
            raise Denied('unknown or already consumed grant')
        issued_for, expires_at = entry
        if self._clock() >= expires_at:
            self._record('expired_grant', req)
            raise Denied('grant expired')
        if req != issued_for:
            self._record('request_mismatch', req)
            raise Denied('grant scope mismatch')
        self._record('operation_authorized', req)
        return {'authorized': True, 'operation': req.operation, 'resource': req.resource,
                'execution_id': req.execution_id}

    def events(self) -> tuple[dict, ...]:
        return tuple(dict(e) for e in self._audit)

    def audit_sha256(self) -> str:
        """Unkeyed digest for reproducibility, NOT tamper-evidence against an attacker."""
        encoded = json.dumps(self._audit, sort_keys=True, separators=(',', ':')).encode()
        return hashlib.sha256(encoded).hexdigest()
