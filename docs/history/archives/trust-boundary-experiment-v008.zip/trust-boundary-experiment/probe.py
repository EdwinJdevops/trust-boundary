"""Harmless synthetic resource-access probe. Do not use real secrets."""
import json
import os
from pathlib import Path
from urllib.request import urlopen


def run():
    results = {}
    secret = Path(os.environ['LAB_SECRET_PATH'])
    try:
        results['read_synthetic_secret'] = secret.read_text().strip() == 'SYNTHETIC_NOT_A_REAL_CREDENTIAL'
    except (OSError, ValueError):
        results['read_synthetic_secret'] = False

    protected = Path(os.environ['LAB_PROTECTED_PATH']) / 'probe-created.txt'
    try:
        protected.write_text('SYNTHETIC_TEST_ONLY\n')
        results['write_protected_host_path'] = True
    except OSError:
        results['write_protected_host_path'] = False

    try:
        with urlopen(os.environ['LAB_MOCK_URL'], timeout=2) as response:
            results['reach_mock_service'] = response.read() == b'MOCK_SERVICE_ONLY'
    except Exception:
        results['reach_mock_service'] = False

    try:
        assert Path('probe.py').is_file()
        Path('/tmp/allowed-output.txt').write_text('ALLOWED\n')
        results['permitted_work_succeeds'] = Path('/tmp/allowed-output.txt').read_text() == 'ALLOWED\n'
    except (OSError, AssertionError):
        results['permitted_work_succeeds'] = False

    print(json.dumps(results, sort_keys=True))


if __name__ == '__main__':
    run()
