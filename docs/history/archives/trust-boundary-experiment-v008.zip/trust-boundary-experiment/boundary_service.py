"""Synthetic Linux Unix-socket authorization broker. Not a production access service."""
import json
import os
import socket
import threading
from pathlib import Path
from authorization import Broker, Request, Denied
from peer_boundary import PeerRegistry, PeerDenied


class BoundaryService:
    def __init__(self, socket_path: Path, allowed: set[tuple[str, str]]):
        self.socket_path = Path(socket_path)
        self.registry = PeerRegistry()
        self.broker = Broker(allowed)
        self._stop = threading.Event()
        self._thread = None
        self._server = None
        self.operations = []

    def start(self):
        if os.name != 'posix' or not hasattr(socket, 'SO_PEERCRED'):
            raise RuntimeError('Linux SO_PEERCRED required')
        if self.socket_path.exists():
            raise RuntimeError('refusing to overwrite socket path')
        self._server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._server.bind(str(self.socket_path))
        os.chmod(self.socket_path, 0o600)
        self._server.listen(8)
        self._server.settimeout(0.15)
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with conn:
                conn.settimeout(2)
                try:
                    identity = self.registry.authenticate(conn)
                    data = bytearray()
                    while b'\n' not in data and len(data) < 8192:
                        chunk = conn.recv(4096)
                        if not chunk:
                            break
                        data.extend(chunk)
                    if b'\n' not in data or len(data) > 8192:
                        raise ValueError('invalid request framing')
                    payload = json.loads(bytes(data).split(b'\n', 1)[0])
                    if not isinstance(payload, dict) or set(payload) != {'operation', 'resource'}:
                        raise ValueError('invalid request schema')
                    if not all(isinstance(payload[k], str) for k in payload):
                        raise ValueError('invalid fields')
                    req = Request(identity.artifact_sha256, identity.execution_id, payload['operation'], payload['resource'])
                    grant = self.broker.issue(req)
                    self.broker.consume(grant, req)
                    # Only acts on synthetic, local operation. Never runs arbitrary commands.
                    self.operations.append({'execution_id': identity.execution_id, 'operation': req.operation, 'resource': req.resource})
                    result = {'ok': True, 'message': 'synthetic operation recorded'}
                except (PeerDenied, Denied, ValueError, json.JSONDecodeError, OSError, UnicodeDecodeError) as exc:
                    result = {'ok': False, 'error': type(exc).__name__}
                try:
                    conn.sendall((json.dumps(result) + '\n').encode())
                except OSError:
                    pass

    def close(self):
        self._stop.set()
        if self._server:
            self._server.close()
        if self._thread:
            self._thread.join(timeout=2)
        self.socket_path.unlink(missing_ok=True)


def request(socket_path: str, operation: str, resource: str) -> dict:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as conn:
        conn.settimeout(3)
        conn.connect(socket_path)
        conn.sendall((json.dumps({'operation': operation, 'resource': resource}) + '\n').encode())
        data = bytearray()
        while b'\n' not in data and len(data) < 8192:
            block = conn.recv(4096)
            if not block:
                break
            data.extend(block)
        return json.loads(bytes(data).split(b'\n', 1)[0])
