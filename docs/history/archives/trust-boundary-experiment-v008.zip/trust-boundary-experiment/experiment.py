"""Local synthetic baseline vs bubblewrap boundary test; standard library only."""
import http.server
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
from artifact_gate import digest, enforce_pinned_artifact


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path != '/mock':
            self.send_error(404)
            return
        payload = b'MOCK_SERVICE_ONLY'
        self.send_response(200)
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *_args):
        pass


def execute(argv, env, cwd):
    proc = subprocess.run(argv, env=env, cwd=cwd, text=True,
                          capture_output=True, timeout=15, check=False)
    if proc.returncode != 0:
        raise RuntimeError(f'Command failed, exit={proc.returncode}: {proc.stderr.strip()}')
    data = json.loads(proc.stdout.strip())
    if not isinstance(data, dict):
        raise RuntimeError('Probe returned a non-object JSON result')
    return data


def main():
    if not sys.platform.startswith('linux'):
        raise SystemExit('Linux required. No fallback that executes untrusted code.')
    bwrap = shutil.which('bwrap')
    if bwrap is None:
        raise SystemExit('bubblewrap (bwrap) is required. Install it on a disposable Linux VM.')
    script = Path(__file__).with_name('probe.py').resolve()
    if not script.is_file():
        raise SystemExit('Missing probe.py')
    probe_sha256 = digest(script)
    with tempfile.TemporaryDirectory(prefix='boundary-lab-') as temp:
        root = Path(temp)
        workspace = root / 'workspace'
        workspace.mkdir()
        (root / 'tmp-baseline').mkdir()
        (workspace / 'probe.py').write_bytes(script.read_bytes())
        # Verify the actual bytes to be executed, not merely repository metadata.
        enforce_pinned_artifact(workspace / 'probe.py', probe_sha256)
        secret = root / 'synthetic-credential'
        secret.write_text('SYNTHETIC_NOT_A_REAL_CREDENTIAL\n')
        protected = root / 'protected'
        protected.mkdir()
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            environment = dict(os.environ)
            environment.update(TMPDIR=str(root / 'tmp-baseline'), LAB_SECRET_PATH=str(secret), LAB_PROTECTED_PATH=str(protected),
                               LAB_MOCK_URL=f'http://127.0.0.1:{server.server_port}/mock')
            baseline = execute([sys.executable, '-B', str(workspace / 'probe.py')], environment, workspace)
            # No host workspace parent, credential, protected directory, user home,
            # Docker socket, or network namespace is exposed to the sandbox.
            argv = [bwrap, '--unshare-all', '--die-with-parent', '--new-session',
                    '--clearenv', '--setenv', 'PATH', '/usr/local/bin:/usr/bin:/bin',
                    '--setenv', 'LAB_SECRET_PATH', str(secret),
                    '--setenv', 'LAB_PROTECTED_PATH', str(protected),
                    '--setenv', 'LAB_MOCK_URL', environment['LAB_MOCK_URL'],
                    '--tmpfs', '/tmp', '--proc', '/proc', '--dev', '/dev']
            for directory in ('/usr', '/usr/local', '/bin', '/lib', '/lib64', '/etc'):
                if Path(directory).exists():
                    argv += ['--ro-bind', directory, directory]
            argv += ['--ro-bind', str(workspace), '/workspace', '--chdir', '/workspace',
                     sys.executable, '-B', '/workspace/probe.py']
            try:
                isolated = execute(argv, {}, workspace)
            except (RuntimeError, subprocess.TimeoutExpired) as error:
                raise SystemExit(f'Sandbox unavailable or misconfigured (FAIL CLOSED): {error}')
            names = ('read_synthetic_secret', 'write_protected_host_path', 'reach_mock_service')
            baseline_ok = all(baseline.get(name) is True for name in names) and baseline.get('permitted_work_succeeds') is True
            isolation_ok = all(isolated.get(name) is False for name in names) and isolated.get('permitted_work_succeeds') is True
            report = {'schema_version': 1, 'probe_sha256': probe_sha256,
                      'baseline': baseline, 'isolated': isolated,
                      'baseline_demonstrates_exposure': baseline_ok,
                      'isolation_checks_pass': isolation_ok}
            print(json.dumps(report, indent=2, sort_keys=True))
            if not (baseline_ok and isolation_ok):
                raise SystemExit('Experiment checks failed; inspect the report.')
        finally:
            server.shutdown()
            server.server_close()


if __name__ == '__main__':
    main()
