"""Integration checks for identity-to-policy wiring. No sandbox or production claims."""
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from boundary_service import BoundaryService, request

ROOT = Path(__file__).resolve().parent
CLIENT = ROOT / 'boundary_client.py'


@unittest.skipUnless(sys.platform.startswith('linux'), 'Linux SO_PEERCRED only')
class BoundaryIntegration(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.sock = Path(self.tmp.name) / 'boundary.sock'
        self.service = BoundaryService(self.sock, {('read', 'mock://status')})
        self.service.start()

    def tearDown(self):
        self.service.close()
        self.tmp.cleanup()

    def launch(self, operation, resource, register=True, artifact_digest=None):
        rd, wr = os.pipe()
        os.set_inheritable(rd, True)
        env = dict(os.environ, BOUNDARY_READY_FD=str(rd))
        p = subprocess.Popen([sys.executable, str(CLIENT), str(self.sock), operation, resource],
                             cwd=str(ROOT), env=env, pass_fds=(rd,), stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, text=True)
        os.close(rd)
        if register:
            digest = artifact_digest or hashlib.sha256(CLIENT.read_bytes()).hexdigest()
            self.service.registry.register(p.pid, os.getuid(), digest, 'run-' + str(p.pid))
        os.write(wr, b'1')
        os.close(wr)
        stdout, stderr = p.communicate(timeout=8)
        self.service.registry.revoke(p.pid)
        self.assertEqual(stderr, '', stderr)
        return p.returncode, json.loads(stdout)

    def test_registered_allowed(self):
        code, response = self.launch('read', 'mock://status')
        self.assertEqual(code, 0)
        self.assertTrue(response['ok'])
        self.assertEqual(len(self.service.operations), 1)

    def test_registered_denied_by_policy(self):
        code, response = self.launch('delete', 'mock://status')
        self.assertEqual(code, 2)
        self.assertFalse(response['ok'])
        self.assertEqual(self.service.operations, [])

    def test_unregistered_denied(self):
        code, response = self.launch('read', 'mock://status', register=False)
        self.assertEqual(code, 2)
        self.assertEqual(response['error'], 'PeerDenied')
        self.assertEqual(self.service.operations, [])

    def test_parent_cannot_impersonate_registered_child(self):
        rd, wr = os.pipe()
        p = subprocess.Popen([sys.executable, '-c', 'import os; os.read(0, 1)'], stdin=rd)
        os.close(rd)
        try:
            self.service.registry.register(p.pid, os.getuid(), 'a'*64, 'other')
            response = request(str(self.sock), 'read', 'mock://status')
            self.assertEqual(response['error'], 'PeerDenied')
        finally:
            os.write(wr, b'1'); os.close(wr)
            p.wait(timeout=5)
            self.service.registry.revoke(p.pid)

    def test_invalid_digest_registration_rejected(self):
        with self.assertRaises(ValueError):
            self.service.registry.register(os.getpid(), os.getuid(), 'not-a-sha', 'run')


if __name__ == '__main__':
    unittest.main()
