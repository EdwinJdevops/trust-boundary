import dataclasses
import hashlib
import tempfile
import threading
import unittest
from pathlib import Path
from release_gate import ReleaseGate, ReleaseIssuer, ReleaseDenied, new_intent

KEY = b'issuer-side-test-secret-do-not-use-in-production'
ARTIFACT = hashlib.sha256(b'image-bytes').hexdigest()
SOURCE = hashlib.sha256(b'source-tree').hexdigest()
POLICY = {'ci-release': {'staging': {('deploy', 'api')}}}

class ReleaseGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'releases.sqlite'
        self.clock = lambda: 1000
        self.gate = ReleaseGate(self.path, KEY, POLICY, self.clock)
        self.issuer = ReleaseIssuer(KEY)
        self.intent = new_intent(ARTIFACT, SOURCE, 'api', 'staging', 'deploy', 'ci-release', now=1000)

    def approve(self, intent=None, signature=None, artifact=ARTIFACT):
        intent = intent or self.intent
        return self.gate.authorize(intent, signature if signature is not None else self.issuer.sign(intent), actual_artifact_sha256=artifact)

    def test_approved_release(self):
        self.assertTrue(self.approve()['authorized'])

    def test_replay_rejected_even_after_gate_restart(self):
        self.approve()
        reopened = ReleaseGate(self.path, KEY, POLICY, self.clock)
        with self.assertRaises(ReleaseDenied):
            reopened.authorize(self.intent, self.issuer.sign(self.intent), actual_artifact_sha256=ARTIFACT)

    def test_environment_escalation_denied(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, environment='production'))

    def test_workload_escalation_denied(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, workload='payments'))

    def test_wrong_artifact_denied(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(artifact=SOURCE)

    def test_tampered_signed_intent_denied(self):
        signature = self.issuer.sign(self.intent)
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, environment='production'), signature)

    def test_expired_intent_denied(self):
        old = new_intent(ARTIFACT, SOURCE, 'api', 'staging', 'deploy', 'ci-release', now=900)
        with self.assertRaises(ReleaseDenied):
            self.approve(old)

    def test_future_long_lived_intent_denied(self):
        future = dataclasses.replace(self.intent, expires_at=1400)
        with self.assertRaises(ReleaseDenied):
            self.approve(future)

    def test_untrusted_issuer_denied(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, issuer='developer-laptop'))

    def test_concurrent_single_use(self):
        outputs = []
        lock = threading.Lock()
        def worker():
            try:
                self.approve()
                value = 'approved'
            except ReleaseDenied:
                value = 'denied'
            with lock:
                outputs.append(value)
        threads = [threading.Thread(target=worker) for _ in range(10)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertEqual(outputs.count('approved'), 1)
        self.assertEqual(outputs.count('denied'), 9)

    def test_missing_scope_denied(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, operation='delete'))

    def test_invalid_digest_rejected(self):
        with self.assertRaises(ReleaseDenied):
            self.approve(dataclasses.replace(self.intent, source_sha256='not-a-digest'))

if __name__ == '__main__':
    unittest.main()
