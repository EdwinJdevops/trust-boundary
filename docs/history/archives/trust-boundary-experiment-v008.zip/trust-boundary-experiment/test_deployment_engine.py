import hashlib
import sqlite3
import tempfile
import unittest
from pathlib import Path
from deployment_engine import DeploymentEngine, MockDeploymentTarget, DeploymentError
from release_gate import ReleaseGate, ReleaseIssuer, ReleaseDenied, new_intent

KEY = b'local-laboratory-signing-key-not-a-production-key'
A = hashlib.sha256(b'artifact').hexdigest()
S = hashlib.sha256(b'source').hexdigest()
POLICY = {'ci': {'staging': {('deploy', 'api')}}}

class DeploymentEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        p = Path(self.temp.name)
        self.gate = ReleaseGate(p/'auth.db', KEY, POLICY, lambda: 1000)
        self.target = MockDeploymentTarget(p/'target.db')
        self.engine_path = p/'operations.db'
        self.engine = DeploymentEngine(self.engine_path, self.gate, self.target)
        self.intent = new_intent(A, S, 'api', 'staging', 'deploy', 'ci', now=1000)
        self.signature = ReleaseIssuer(KEY).sign(self.intent)

    def submit(self, **kw):
        return self.engine.submit(self.intent, self.signature, A, **kw)

    def test_success_is_durable(self):
        result = self.submit()
        self.assertEqual(result['state'], 'SUCCEEDED')
        reopened = DeploymentEngine(self.engine_path, self.gate, self.target)
        self.assertEqual(reopened.reconcile(result['operation_id'])['state'], 'SUCCEEDED')

    def test_response_loss_reconciles_without_duplicate_mutation(self):
        result = self.submit(lose_response=True)
        self.assertEqual(result['state'], 'UNCERTAIN')
        self.assertEqual(self.engine.reconcile(result['operation_id'])['state'], 'SUCCEEDED')
        with sqlite3.connect(self.target.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM applied').fetchone()[0], 1)

    def test_crash_after_pending_record_retries_safely(self):
        decision = self.gate.authorize(self.intent, self.signature, actual_artifact_sha256=A)
        op = self.engine.operation_id(self.intent)
        with sqlite3.connect(self.engine_path) as db:
            db.execute('INSERT INTO deployments VALUES (?, ?, ?, ?, NULL)',(op,decision['intent_sha256'], A, 'PENDING'))
        self.assertEqual(self.engine.reconcile(op)['state'], 'SUCCEEDED')

    def test_replay_does_not_issue_second_deployment(self):
        self.submit()
        with self.assertRaises(ReleaseDenied):
            self.submit()

    def test_unauthorized_target_never_modified(self):
        from dataclasses import replace
        invalid = replace(self.intent, environment='production')
        with self.assertRaises(ReleaseDenied):
            self.engine.submit(invalid, ReleaseIssuer(KEY).sign(invalid), A)
        with sqlite3.connect(self.target.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM applied').fetchone()[0],0)

    def test_target_idempotency_collision_denied(self):
        self.target.apply('same','hash1',A)
        with self.assertRaises(DeploymentError):
            self.target.apply('same','hash2',A)

    def test_unknown_operation_cannot_be_reconciled(self):
        with self.assertRaises(DeploymentError):
            self.engine.reconcile('nonexistent')

    def test_conflicting_target_evidence_blocks_recovery(self):
        decision = self.gate.authorize(self.intent, self.signature, actual_artifact_sha256=A)
        op = self.engine.operation_id(self.intent)
        with sqlite3.connect(self.engine_path) as db:
            db.execute('INSERT INTO deployments VALUES (?, ?, ?, ?, NULL)',(op,decision['intent_sha256'], A, 'UNCERTAIN'))
        self.target.apply(op, 'different', A)
        with self.assertRaises(DeploymentError):
            self.engine.reconcile(op)

if __name__ == '__main__':
    unittest.main()
