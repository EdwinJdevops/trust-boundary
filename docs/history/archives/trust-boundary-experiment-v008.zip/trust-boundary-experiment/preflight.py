"""Read-only Linux sandbox prerequisites; never grants additional privileges."""
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def read(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def main():
    bwrap = shutil.which('bwrap')
    report = {
        'schema_version': 1,
        'system': platform.system(),
        'release': platform.release(),
        'machine': platform.machine(),
        'euid_is_nonroot': getattr(os, 'geteuid', lambda: 0)() != 0,
        'bwrap_present': bwrap is not None,
        'max_user_namespaces': read('/proc/sys/user/max_user_namespaces'),
        'unprivileged_userns_clone': read('/proc/sys/kernel/unprivileged_userns_clone'),
        'apparmor_restrict_unprivileged_userns': read('/proc/sys/kernel/apparmor_restrict_unprivileged_userns'),
    }
    if bwrap and report['system'] == 'Linux' and report['euid_is_nonroot']:
        try:
            # Smoke test only: this does not establish containment of hostile code.
            result = subprocess.run(
                [bwrap, '--unshare-all', '--die-with-parent', '--ro-bind', '/', '/', '--', '/bin/true'],
                capture_output=True, text=True, timeout=10, check=False,
            )
            report['namespace_smoke_test_ok'] = result.returncode == 0
            report['namespace_smoke_test_error'] = result.stderr.strip()[:400] if result.returncode else None
        except (OSError, subprocess.TimeoutExpired) as error:
            report['namespace_smoke_test_ok'] = False
            report['namespace_smoke_test_error'] = str(error)[:400]
    else:
        report['namespace_smoke_test_ok'] = False
        report['namespace_smoke_test_error'] = 'Requires non-root Linux session with bwrap installed'
    report['ready'] = bool(report['namespace_smoke_test_ok'])
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report['ready'] else 2


if __name__ == '__main__':
    sys.exit(main())
