"""Fail-closed SHA-256 artifact identity gate; this is NOT a malware detector."""
import hashlib
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def enforce_pinned_artifact(path: Path, expected_sha256: str) -> str:
    if len(expected_sha256) != 64 or any(c not in '0123456789abcdef' for c in expected_sha256):
        raise ValueError('Expected SHA-256 must be exactly 64 lowercase hexadecimal characters')
    actual = digest(path)
    if actual != expected_sha256:
        raise ValueError('Artifact identity mismatch: execution denied')
    return actual
