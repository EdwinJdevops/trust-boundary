"""Linux executable-image verification for trusted launcher experiments.

Checks the /proc PID executable image, NOT scripts, loaded libraries, or runtime state.
Never label a Python script attested using this primitive alone.
"""
import hashlib
import os
from pathlib import Path


def executable_digest(pid: int) -> str:
    if not isinstance(pid, int) or pid <= 0:
        raise ValueError('PID must be a positive integer')
    fd = os.open(f'/proc/{pid}/exe', os.O_RDONLY | os.O_CLOEXEC)
    try:
        h = hashlib.sha256()
        while True:
            block = os.read(fd, 1024 * 1024)
            if not block:
                break
            h.update(block)
        return h.hexdigest()
    finally:
        os.close(fd)


def executable_file_id(pid: int) -> tuple[int, int]:
    st = os.stat(f'/proc/{pid}/exe')
    return st.st_dev, st.st_ino
