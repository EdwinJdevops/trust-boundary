"""Adversarial controls: demonstrate exactly what process-image identity proves."""
import hashlib
import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from peer_boundary import PeerRegistry, PeerDenied
from verified_executable import executable_digest, executable_file_id
from boundary_service import BoundaryService, request

@unittest.skipUnless(sys.platform.startswith('linux'), 'requires Linux /proc and SO_PEERCRED')
class ExecutableIdentityTests(unittest.TestCase):
    def test_verified_current_process(self):
        reg = PeerRegistry()
        sha = executable_digest(os.getpid())
        reg.register_verified_executable(os.getpid(), os.getuid(), sha, 'exec-a')
        a,b = socket.socketpair(socket.AF_UNIX)
        try:
            identity = reg.authenticate(a)
            self.assertTrue(identity.verified_executable)
            self.assertEqual(identity.artifact_sha256, sha)
        finally:
            a.close(); b.close()

    def test_forged_artifact_hash_rejected(self):
        reg = PeerRegistry()
        sha = executable_digest(os.getpid())
        wrong = '0'*64 if sha != '0'*64 else '1'*64
        with self.assertRaises(PeerDenied):
            reg.register_verified_executable(os.getpid(), os.getuid(), wrong, 'exec-a')

    def test_executable_change_rejected_at_authentication(self):
        reg = PeerRegistry()
        sha = executable_digest(os.getpid())
        reg.register_verified_executable(os.getpid(), os.getuid(), sha, 'exec-a')
        a,b = socket.socketpair(socket.AF_UNIX)
        try:
            with patch('peer_boundary.executable_file_id', return_value=(0, 0)):
                with self.assertRaisesRegex(PeerDenied, 'executable image changed'):
                    reg.authenticate(a)
        finally:
            a.close(); b.close()

    def test_unverified_legacy_registration_remains_untrusted(self):
        reg = PeerRegistry()
        entry = reg.register(os.getpid(), os.getuid(), 'f'*64, 'exec-a')
        self.assertFalse(entry.verified_executable)

    def test_direct_resource_bypass_is_not_prevented(self):
        # Demonstrates limitation: no network enforcement is installed here.
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'resource'
            path.write_text('synthetic-protected-operation')
            self.assertEqual(path.read_text(), 'synthetic-protected-operation')
            # A policy broker cannot protect resources independently reachable by a process.

if __name__ == '__main__':
    unittest.main()
