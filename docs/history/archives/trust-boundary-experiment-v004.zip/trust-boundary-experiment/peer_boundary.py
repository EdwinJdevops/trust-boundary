"""Linux-only local identity gate. Experimental: not a secure sandbox or SPIFFE replacement."""
import json
import os
import socket
import struct
import threading
from dataclasses import dataclass


class PeerDenied(Exception):
    pass


def linux_process_start_ticks(pid: int) -> int:
    # /proc/PID/stat field 22; comm in parentheses can contain spaces or ')'.
    with open(f'/proc/{pid}/stat', encoding='utf-8') as f:
        stat = f.read()
    rest = stat[stat.rfind(')') + 2:].split()
    return int(rest[19])


@dataclass(frozen=True)
class AttestedExecution:
    pid: int
    uid: int
    start_ticks: int
    artifact_sha256: str
    execution_id: str


class PeerRegistry:
    """Registrations must come from a trusted launcher via direct call, not the socket."""
    def __init__(self):
        self._entries = {}
        self._lock = threading.Lock()

    def register(self, pid: int, uid: int, artifact_sha256: str, execution_id: str):
        if len(artifact_sha256) != 64 or any(c not in '0123456789abcdef' for c in artifact_sha256):
            raise ValueError('invalid SHA-256')
        if not execution_id:
            raise ValueError('execution ID required')
        entry = AttestedExecution(pid, uid, linux_process_start_ticks(pid), artifact_sha256, execution_id)
        with self._lock:
            self._entries[pid] = entry
        return entry

    def revoke(self, pid: int):
        with self._lock:
            self._entries.pop(pid, None)

    def authenticate(self, connection: socket.socket) -> AttestedExecution:
        if not hasattr(socket, 'SO_PEERCRED'):
            raise PeerDenied('Linux SO_PEERCRED unavailable')
        raw = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize('3i'))
        pid, uid, _gid = struct.unpack('3i', raw)
        with self._lock:
            entry = self._entries.get(pid)
        if entry is None or entry.uid != uid:
            raise PeerDenied('unregistered process')
        try:
            actual_start = linux_process_start_ticks(pid)
        except (FileNotFoundError, ProcessLookupError, PermissionError) as exc:
            raise PeerDenied('cannot verify process lifetime') from exc
        if actual_start != entry.start_ticks:
            raise PeerDenied('process identity changed')
        return entry
