# Trust boundary experiment 001

## Purpose

Compare a **harmless synthetic probe** on the developer host with the same probe in a Bubblewrap-based Linux sandbox. Tests: read synthetic credential, write protected synthetic folder, reach loopback mock service. No malware and no real credentials are involved.

## Requirements

- Disposable Linux VM (recommended), Python 3.9+, `bubblewrap` (`bwrap`).
- User namespaces permitted by the Linux distribution's security settings.
- No AWS credentials, Kubernetes contexts, real secrets, production network connections or active cloud account are required.

## Run

From this directory, on the Linux VM:

```bash
python3 experiment.py
```

The script fails closed if `bwrap` is missing or namespace construction fails. It does **not** silently run the intended sandbox probe directly on the host. The baseline runs a known, local harmless probe only.

## Expected assertions (NOT execution results)

- Baseline: three `true` outcomes: fixture secret readable, fixture directory writable, local mock service reachable.
- Sandboxed: three `false` outcomes: the same host fixture resources are inaccessible.

Exit status 0 means both conditions were met. If namespace configuration is disallowed (possible with Linux security policy or WSL), the program stops without claiming successful isolation.

## Scope and limitations

This is an educational boundary test, **not** a production sandbox. It does not demonstrate containment of arbitrary malicious code, container escapes, denial-of-service, side channels, inherited file descriptors, supply-chain tampering, or secure live authorization. Bubblewrap relies on the invoking host kernel and selected namespace/mount restrictions; stronger isolation for untrusted workloads may require a VM or gVisor-style application kernel. Bind mounting the host's software directories is deliberate for this synthetic proof-of-concept and is not a hardened filesystem policy. Run inside a disposable VM; do not execute third-party software using this harness. `--unshare-all` removes networking for the sandbox, so package downloads inside it are intentionally unsupported.

## Next research decision

Measure usability for real developer workflows separately, then evaluate sandbox escape resistance and a credential broker using a more suitable isolation substrate. Do not use output as evidence of production readiness.

## Experiment 001B: positive control and evidence

This revision also tests **permitted execution**: the probe must read its own script and write/read a synthetic file in `/tmp`. A deny-everything sandbox therefore cannot pass. Successful outcomes are baseline: four `true`; sandbox: three denials (`false`) and permitted execution (`true`). Reports include the exact probe SHA-256. The unit tests cover the static test contract only; they do not prove sandbox security.

Run unit tests without Bubblewrap:

```bash
python3 -m unittest -v test_contract.py
```

## Known limitations and follow-up attacks

- The baseline writes a harmless file under `/tmp` in a disposable VM and the sandbox uses a private `/tmp` mount. Do **not** execute this code on a production workstation.
- The fixture paths, not real cloud or Kubernetes secrets, are used for boundary checks.
- The mock URL comes from a randomly selected local loopback port. The sandbox must not inherit host networking.
- `--ro-bind` of system locations allows reading some host system files. This proof-of-concept is not a generalized read-isolated filesystem and must not run third-party binaries.
- No CPU, memory or process-count limits are configured. Use an outer disposable VM with resource quotas.
- Production design requires non-root execution, network egress controls, immutable artifacts, a trustworthy policy decision/enforcement point, and independent workload identity enforcement.
- **Gate for next phase:** run on a disposable Linux VM; inspect both controls and report. Then conduct independent adversarial review before supporting any actual untrusted code.
