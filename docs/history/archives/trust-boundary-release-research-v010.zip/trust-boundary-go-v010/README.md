# Trust Boundary — Go release-authority experiment 010

This is an experimental authorization core, **not a deployable production control plane**. It extends the Python Experiment 009 as a separate module rather than silently replacing it.

## Verified contract

- Ed25519 signature on a fixed JSON intent schema; issuer private key is not needed by verifier.
- Exact SHA-256 artifact digest, issuer, workload, target environment, operation, expiry and nonce matching.
- Fail-closed single-use local replay record using atomic exclusive file creation and filesystem sync.
- No dependencies outside Go's standard library.

## Test

`go test -race -count=1 ./...`

## Trust assumptions and current blockers

1. The `observedDigest` argument MUST be supplied by a separate trusted executor measuring real bytes. Passing an attacker-supplied value destroys artifact binding.
2. Only a private, locally controlled replay directory is supported. Filesystem durability semantics depend on filesystem/platform; NFS/distributed execution is outside scope. The verifier does not securely establish the owner of the directory or prevent a privileged adversary from altering it.
3. Recording authorization is not the same as recording successful deployment. This module doesn't execute cluster changes or recover external mutations.
4. There is no trusted launcher, no proven isolation, no SPIFFE identity, no Kubernetes adapter, no signing-key lifecycle, no audited event storage, and no protected remote protocol.
5. A local caller using a trusted executor's identity might still request authorization: real authentication, workload attestation and OS separation must be tested.
6. The verifier is suitable for engineering research and CI tests, not production authorization.

## Launch gates

A public engineering preview must clearly identify these limits. A production release must additionally demonstrate independent OS identities, confined executor, strict network policies, protected keys, trusted artifact measurement, Kubernetes mutation restrictions, state reconciliation, telemetry, and adversarial testing under real Linux isolation.
