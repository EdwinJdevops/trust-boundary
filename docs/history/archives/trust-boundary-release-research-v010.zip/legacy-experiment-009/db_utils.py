"""SQLite transaction context that reliably closes connections on all Python versions."""
from contextlib import contextmanager
import sqlite3

@contextmanager
def closing_db(*args, **kwargs):
    connection = sqlite3.connect(*args, **kwargs)
    try:
        with connection:
            yield connection
    finally:
        connection.close()
