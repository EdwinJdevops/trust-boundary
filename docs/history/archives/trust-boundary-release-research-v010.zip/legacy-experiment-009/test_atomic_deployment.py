from db_utils import closing_db
import hashlib
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from deployment_engine import AtomicDeploymentEngine, MockDeploymentTarget, DeploymentError
from release_gate import ReleaseGate, ReleaseIssuer, ReleaseDenied, new_intent

KEY = b'local-laboratory-signing-key-not-a-production-key'
ARTIFACT = hashlib.sha256(b'artifact').hexdigest()
SOURCE = hashlib.sha256(b'source').hexdigest()
POLICY = {'ci': {'staging': {('deploy', 'api')}}}

class AtomicDeploymentTests(unittest.TestCase):
    def setUp(self):
        t = tempfile.TemporaryDirectory()
        self.addCleanup(t.cleanup)
        directory = Path(t.name)
        self.path = directory / 'shared.db'
        self.gate = ReleaseGate(self.path, KEY, POLICY, lambda: 1000)
        self.target = MockDeploymentTarget(directory / 'target.db')
        self.engine = AtomicDeploymentEngine(self.path, self.gate, self.target)
        self.intent = new_intent(ARTIFACT, SOURCE, 'api', 'staging', 'deploy', 'ci', now=1000)
        self.signature = ReleaseIssuer(KEY).sign(self.intent)

    def test_commit_records_authorization_and_deployment(self):
        result = self.engine.submit(self.intent, self.signature, ARTIFACT)
        self.assertEqual(result['state'], 'SUCCEEDED')
        with closing_db(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM consumed').fetchone()[0], 1)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM deployments').fetchone()[0], 1)

    def test_crash_before_commit_rolls_back_both(self):
        with self.assertRaisesRegex(DeploymentError, 'injected crash'):
            self.engine.submit(self.intent, self.signature, ARTIFACT, fail_before_commit=True)
        with closing_db(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM consumed').fetchone()[0], 0)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM deployments').fetchone()[0], 0)
        self.assertEqual(self.engine.submit(self.intent, self.signature, ARTIFACT)['state'], 'SUCCEEDED')

    def test_replay_rejected_without_extra_mutation(self):
        self.engine.submit(self.intent, self.signature, ARTIFACT)
        with self.assertRaises(ReleaseDenied):
            self.engine.submit(self.intent, self.signature, ARTIFACT)
        with closing_db(self.target.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM applied').fetchone()[0], 1)

    def test_uncertain_outcome_recovers_after_restart(self):
        result = self.engine.submit(self.intent, self.signature, ARTIFACT, lose_response=True)
        self.assertEqual(result['state'], 'UNCERTAIN')
        restarted = AtomicDeploymentEngine(self.path, self.gate, self.target)
        self.assertEqual(restarted.reconcile(result['operation_id'])['state'], 'SUCCEEDED')

    def test_separate_database_rejected(self):
        with self.assertRaises(ValueError):
            AtomicDeploymentEngine(self.path.parent / 'other.db', self.gate, self.target)

    def test_parallel_submits_one_winner(self):
        results = []
        lock = threading.Lock()
        def run():
            try:
                value = self.engine.submit(self.intent, self.signature, ARTIFACT)['state']
            except ReleaseDenied:
                value = 'DENIED'
            with lock:
                results.append(value)
        threads = [threading.Thread(target=run) for _ in range(8)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertEqual(sorted(results), ['DENIED'] * 7 + ['SUCCEEDED'])

if __name__ == '__main__':
    unittest.main()
