"""Linux-only protected mock deployment adapter.

OS socket permissions are useful only when broker and untrusted workloads run
under DIFFERENT Unix identities. No claim of protection against same-UID clients.
"""
from __future__ import annotations
from db_utils import closing_db
import json
import os
import socket
import sqlite3
import struct
import threading
import time
from pathlib import Path

class AdapterDenied(Exception):
    pass

class ProtectedAdapterServer:
    def __init__(self, socket_path: str | Path, database: str | Path, *, allowed_uid: int):
        self.socket_path = str(socket_path)
        self.database = str(database)
        self.allowed_uid = allowed_uid
        self._stop = threading.Event()
        self._thread = None
        self._socket = None
        with closing_db(self.database) as db:
            db.execute('''CREATE TABLE IF NOT EXISTS applied (
                operation_id TEXT PRIMARY KEY, request_hash TEXT NOT NULL,
                artifact TEXT NOT NULL, applied_at INTEGER NOT NULL)''')

    def start(self):
        if os.path.lexists(self.socket_path):
            raise RuntimeError('socket path already exists; refusing to unlink')
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            sock.bind(self.socket_path)
            os.chmod(self.socket_path, 0o600)
            sock.listen(8)
            sock.settimeout(0.2)
        except BaseException:
            sock.close()
            raise
        self._socket = sock
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def close(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)
        if self._socket:
            self._socket.close()
        if os.path.exists(self.socket_path):
            os.unlink(self.socket_path)

    def _serve(self):
        while not self._stop.is_set():
            try:
                connection, _ = self._socket.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            with connection:
                connection.settimeout(3)
                try:
                    pid, uid, gid = struct.unpack('3i', connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
                    if uid != self.allowed_uid:
                        raise AdapterDenied('peer uid denied')
                    raw = bytearray()
                    while not raw.endswith(b'\n'):
                        part = connection.recv(4096)
                        if not part or len(raw) + len(part) > 8192:
                            raise AdapterDenied('invalid request frame')
                        raw.extend(part)
                    request = json.loads(raw)
                    if not isinstance(request, dict) or request.get('action') not in ('apply', 'inspect'):
                        raise AdapterDenied('unsupported action')
                    op_id = request.get('operation_id')
                    if not isinstance(op_id, str) or len(op_id) != 64 or any(c not in '0123456789abcdef' for c in op_id):
                        raise AdapterDenied('invalid operation id')
                    if request['action'] == 'apply':
                        if set(request) != {'action','operation_id','request_hash','artifact'}:
                            raise AdapterDenied('unknown fields')
                        h, a = request['request_hash'], request['artifact']
                        if any(not isinstance(v,str) or len(v) != 64 or any(c not in '0123456789abcdef' for c in v) for v in (h,a)):
                            raise AdapterDenied('invalid identity digest')
                        with closing_db(self.database, timeout=5, isolation_level=None) as db:
                            db.execute('BEGIN IMMEDIATE')
                            existing = db.execute('SELECT request_hash, artifact FROM applied WHERE operation_id=?',(op_id,)).fetchone()
                            if existing and existing != (h,a):
                                raise AdapterDenied('idempotency conflict')
                            if existing is None:
                                db.execute('INSERT INTO applied VALUES (?,?,?,?)',(op_id,h,a,int(time.time())))
                            db.execute('COMMIT')
                        result = {'status':'already_applied' if existing else 'applied'}
                    else:
                        if set(request) != {'action','operation_id'}:
                            raise AdapterDenied('unknown fields')
                        with closing_db(self.database) as db:
                            existing = db.execute('SELECT request_hash, artifact FROM applied WHERE operation_id=?',(op_id,)).fetchone()
                        result = {'record': {'request_hash':existing[0],'artifact':existing[1]} if existing else None}
                    connection.sendall(json.dumps({'ok':True,**result}).encode()+b'\n')
                except (AdapterDenied, ValueError, TypeError, KeyError, json.JSONDecodeError, socket.timeout, sqlite3.Error) as exc:
                    try: connection.sendall(json.dumps({'ok':False,'error':str(exc)}).encode()+b'\n')
                    except OSError: pass

class ProtectedAdapterClient:
    def __init__(self, socket_path: str | Path):
        self.socket_path = str(socket_path)

    def _request(self, payload):
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(4)
            client.connect(self.socket_path)
            client.sendall(json.dumps(payload, sort_keys=True).encode()+b'\n')
            data = bytearray()
            while not data.endswith(b'\n'):
                part = client.recv(4096)
                if not part or len(data)+len(part)>8192:
                    raise AdapterDenied('invalid adapter response')
                data.extend(part)
        result = json.loads(data)
        if not result.get('ok'):
            raise AdapterDenied(result.get('error','adapter rejected request'))
        return result

    def apply(self, operation_id, request_hash, artifact, *, lose_response=False):
        result = self._request({'action':'apply','operation_id':operation_id,'request_hash':request_hash,'artifact':artifact})
        if lose_response:
            from deployment_engine import UncertainOutcome
            raise UncertainOutcome('simulated lost response after committed adapter mutation')
        return result['status']

    def inspect(self, operation_id):
        return self._request({'action':'inspect','operation_id':operation_id})['record']
