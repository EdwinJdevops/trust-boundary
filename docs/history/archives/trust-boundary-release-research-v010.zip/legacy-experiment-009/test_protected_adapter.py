from db_utils import closing_db
import hashlib
import os
import socket
import sqlite3
import tempfile
import unittest
from pathlib import Path
from protected_adapter import ProtectedAdapterServer, ProtectedAdapterClient, AdapterDenied
from release_gate import ReleaseGate, ReleaseIssuer, new_intent, ReleaseDenied
from deployment_engine import AtomicDeploymentEngine

KEY=b'local-laboratory-signing-key-not-a-production-key'
A=hashlib.sha256(b'artifact').hexdigest()
S=hashlib.sha256(b'source').hexdigest()
H=hashlib.sha256(b'request').hexdigest()

@unittest.skipUnless(hasattr(socket, 'SO_PEERCRED') and hasattr(os,'getuid'), 'Linux SO_PEERCRED required')
class ProtectedAdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        self.server=ProtectedAdapterServer(root/'adapter.sock',root/'target.db',allowed_uid=os.getuid())
        self.server.start()
        self.addCleanup(self.server.close)
        self.client=ProtectedAdapterClient(root/'adapter.sock')
        self.op=hashlib.sha256(b'operation').hexdigest()
        path=root/'control.db'
        self.gate=ReleaseGate(path,KEY,{'ci':{'staging':{('deploy','api')}}},lambda:1000)
        self.engine=AtomicDeploymentEngine(path,self.gate,self.client)
        self.intent=new_intent(A,S,'api','staging','deploy','ci',now=1000)
        self.signature=ReleaseIssuer(KEY).sign(self.intent)

    def test_authorized_deployment_and_readback(self):
        result=self.engine.submit(self.intent,self.signature,A)
        self.assertEqual(result['state'],'SUCCEEDED')
        observed=self.client.inspect(result['operation_id'])
        self.assertEqual(observed['artifact'],A)

    def test_uncertain_response_reconciliation(self):
        result=self.engine.submit(self.intent,self.signature,A,lose_response=True)
        self.assertEqual(result['state'],'UNCERTAIN')
        self.assertEqual(self.engine.reconcile(result['operation_id'])['state'],'SUCCEEDED')

    def test_replayed_authorization_does_not_mutate(self):
        self.engine.submit(self.intent,self.signature,A)
        with self.assertRaises(ReleaseDenied): self.engine.submit(self.intent,self.signature,A)

    def test_conflicting_idempotency_key_is_denied(self):
        self.client.apply(self.op,H,A)
        with self.assertRaises(AdapterDenied): self.client.apply(self.op,A,A)
        self.assertEqual(self.client.inspect(self.op)['request_hash'],H)

    def test_non_allowlisted_request_denied(self):
        with self.assertRaises(AdapterDenied):
            self.client._request({'action':'shell','operation_id':self.op})

    def test_wrong_peer_uid_is_denied(self):
        self.server.allowed_uid=-1
        with self.assertRaises(AdapterDenied): self.client.apply(self.op,H,A)
        with closing_db(self.server.database) as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM applied").fetchone()[0], 0)

    def test_same_uid_direct_call_remains_possible_and_is_documented(self):
        # Negative security test: same-UID untrusted process can bypass the broker.
        self.assertEqual(self.client.apply(self.op,H,A),'applied')
        self.assertIsNotNone(self.client.inspect(self.op))

if __name__=='__main__': unittest.main()
