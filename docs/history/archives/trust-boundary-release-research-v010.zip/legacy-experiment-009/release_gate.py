"""Offline release-authorization contract. NOT a production deployment authority.

Trusted issuer and gate share a secret in this test implementation. Neither
workload attestation nor real cloud/Kubernetes enforcement is provided.
"""
from db_utils import closing_db
from dataclasses import dataclass
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import time
from pathlib import Path

HEX = re.compile(r'^[0-9a-f]{64}$')
NAME = re.compile(r'^[a-z0-9][a-z0-9.-]{0,127}$')

class ReleaseDenied(Exception):
    pass

@dataclass(frozen=True)
class ReleaseIntent:
    artifact_sha256: str
    source_sha256: str
    workload: str
    environment: str
    operation: str
    issuer: str
    expires_at: int
    nonce: str

    def encode(self) -> bytes:
        return json.dumps(self.__dict__, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')

    def validate(self):
        if not all(isinstance(x, str) and HEX.fullmatch(x) for x in (self.artifact_sha256, self.source_sha256)):
            raise ReleaseDenied('invalid artifact/source identity')
        if not all(isinstance(x, str) and NAME.fullmatch(x) for x in (self.workload, self.environment, self.operation, self.issuer)):
            raise ReleaseDenied('invalid scope')
        if not isinstance(self.expires_at, int) or isinstance(self.expires_at, bool) or self.expires_at <= 0:
            raise ReleaseDenied('invalid expiry')
        if not isinstance(self.nonce, str) or not re.fullmatch(r'[0-9a-f]{32}', self.nonce):
            raise ReleaseDenied('invalid nonce')

class ReleaseIssuer:
    """Issuer must be run as a separate trusted service in a future system."""
    def __init__(self, signing_key: bytes):
        if not isinstance(signing_key, bytes) or len(signing_key) < 32:
            raise ValueError('signing key requires at least 32 bytes')
        self._key = signing_key

    def sign(self, intent: ReleaseIntent) -> str:
        intent.validate()
        return hmac.new(self._key, intent.encode(), hashlib.sha256).hexdigest()

class ReleaseGate:
    """SQLite atomic consume. Applies to one local gate/DB, not distributed deployment."""
    def __init__(self, path: str | Path, signing_key: bytes, policy: dict, clock=None):
        if not isinstance(signing_key, bytes) or len(signing_key) < 32:
            raise ValueError('signing key requires at least 32 bytes')
        self.path = str(path)
        self.key = signing_key
        self.policy = policy
        self.clock = clock if clock is not None else time.time
        with closing_db(self.path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS consumed (nonce TEXT PRIMARY KEY, intent_hash TEXT NOT NULL, used_at INTEGER NOT NULL)')

    def validate_intent(self, intent: ReleaseIntent, signature: str, *, actual_artifact_sha256: str) -> dict:
        """Validate without consuming a grant; caller must atomically record consumption."""
        intent.validate()
        if not isinstance(signature, str) or not re.fullmatch(r'[0-9a-f]{64}', signature):
            raise ReleaseDenied('invalid signature')
        expected = hmac.new(self.key, intent.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            raise ReleaseDenied('signature mismatch')
        now = int(self.clock())
        if now >= intent.expires_at or intent.expires_at - now > 300:
            raise ReleaseDenied('expired or excessive grant lifetime')
        if not isinstance(actual_artifact_sha256, str) or not hmac.compare_digest(actual_artifact_sha256, intent.artifact_sha256):
            raise ReleaseDenied('executed artifact differs from release intent')
        allowed = self.policy.get(intent.issuer, {}).get(intent.environment, set())
        if (intent.operation, intent.workload) not in allowed:
            raise ReleaseDenied('operation denied by policy')
        digest = hashlib.sha256(intent.encode()).hexdigest()
        return {'authorized': True, 'intent_sha256': digest, 'workload': intent.workload,
                'environment': intent.environment, 'operation': intent.operation, 'used_at': now}

    def consume_in_transaction(self, db: sqlite3.Connection, intent: ReleaseIntent, decision: dict) -> None:
        """Must be called inside a BEGIN IMMEDIATE transaction on this gate's database."""
        try:
            db.execute('INSERT INTO consumed VALUES (?, ?, ?)',
                       (intent.nonce, decision['intent_sha256'], decision['used_at']))
        except sqlite3.IntegrityError as exc:
            raise ReleaseDenied('release authorization replay') from exc

    def authorize(self, intent: ReleaseIntent, signature: str, *, actual_artifact_sha256: str) -> dict:
        decision = self.validate_intent(intent, signature, actual_artifact_sha256=actual_artifact_sha256)
        with closing_db(self.path, timeout=5, isolation_level=None) as db:
            db.execute('BEGIN IMMEDIATE')
            self.consume_in_transaction(db, intent, decision)
            db.execute('COMMIT')
        return {k: v for k, v in decision.items() if k != 'used_at'}

def new_intent(artifact_sha256: str, source_sha256: str, workload: str, environment: str,
               operation: str, issuer: str, *, now: int | None = None, ttl: int = 60) -> ReleaseIntent:
    if not isinstance(ttl, int) or isinstance(ttl, bool) or not 1 <= ttl <= 300:
        raise ValueError('TTL must be between 1 and 300')
    timestamp = int(time.time() if now is None else now)
    return ReleaseIntent(artifact_sha256, source_sha256, workload, environment, operation,
                         issuer, timestamp + ttl, secrets.token_hex(16))
