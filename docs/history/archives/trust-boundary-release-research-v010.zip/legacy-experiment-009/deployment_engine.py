"""Local deployment transaction laboratory.

This is NOT a production cloud adapter. Durable authorization/intent recording,
backend idempotency, and reconciliation are modeled with SQLite and a mock target.
"""
from __future__ import annotations
from db_utils import closing_db
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from release_gate import ReleaseGate, ReleaseIntent, ReleaseDenied


class DeploymentError(Exception):
    pass


class UncertainOutcome(DeploymentError):
    pass


class MockDeploymentTarget:
    """Separate durable mock target, modeling an adapter with an idempotency ledger."""
    def __init__(self, db_path: str | Path):
        self.path = str(db_path)
        with closing_db(self.path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS applied (operation_id TEXT PRIMARY KEY, request_hash TEXT NOT NULL, artifact TEXT NOT NULL, applied_at INTEGER NOT NULL)')

    def apply(self, operation_id: str, request_hash: str, artifact: str, *, lose_response: bool = False) -> str:
        if not operation_id or not request_hash or not artifact:
            raise DeploymentError('missing operation attributes')
        with closing_db(self.path, timeout=5, isolation_level=None) as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT request_hash FROM applied WHERE operation_id=?', (operation_id,)).fetchone()
            if row and row[0] != request_hash:
                db.execute('ROLLBACK')
                raise DeploymentError('idempotency key collision')
            if not row:
                db.execute('INSERT INTO applied VALUES (?, ?, ?, ?)', (operation_id, request_hash, artifact, int(time.time())))
            db.execute('COMMIT')
        if lose_response:
            raise UncertainOutcome('mock target applied operation but response was lost')
        return 'already_applied' if row else 'applied'

    def inspect(self, operation_id: str) -> dict | None:
        with closing_db(self.path) as db:
            row = db.execute('SELECT request_hash, artifact FROM applied WHERE operation_id=?', (operation_id,)).fetchone()
        return {'request_hash': row[0], 'artifact': row[1]} if row else None


class DeploymentEngine:
    """A single-process control-plane prototype with durable recovery records.

    The mock target keeps idempotency independently from this DB. Real integration
    requires a protected adapter supporting read-after-write or idempotent apply.
    """
    def __init__(self, path: str | Path, release_gate: ReleaseGate, target: MockDeploymentTarget):
        self.path = str(path)
        self.gate = release_gate
        self.target = target
        with closing_db(self.path) as db:
            db.execute('''CREATE TABLE IF NOT EXISTS deployments (
                operation_id TEXT PRIMARY KEY,
                request_hash TEXT NOT NULL,
                artifact TEXT NOT NULL,
                state TEXT NOT NULL CHECK(state IN ('PENDING','SUCCEEDED','UNCERTAIN')),
                target_result TEXT
            )''')

    @staticmethod
    def operation_id(intent: ReleaseIntent) -> str:
        return hashlib.sha256(b'deploy-v1\0' + intent.encode()).hexdigest()

    def submit(self, intent: ReleaseIntent, signature: str, actual_artifact_sha256: str, *, lose_response: bool = False) -> dict:
        # Authorization is consumed before writing a deployment record. A crash
        # between those operations yields a denied retry: an explicit availability
        # limitation, never an authorization bypass.
        authorized = self.gate.authorize(intent, signature, actual_artifact_sha256=actual_artifact_sha256)
        op_id = self.operation_id(intent)
        request_hash = authorized['intent_sha256']
        with closing_db(self.path, timeout=5, isolation_level=None) as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO deployments VALUES (?, ?, ?, ?, NULL)',
                       (op_id, request_hash, actual_artifact_sha256, 'PENDING'))
            db.execute('COMMIT')
        return self._execute(op_id, lose_response=lose_response)

    def _execute(self, operation_id: str, *, lose_response: bool = False) -> dict:
        row = self._row(operation_id)
        if row is None:
            raise DeploymentError('unknown operation')
        request_hash, artifact, state, _ = row
        if state == 'SUCCEEDED':
            return {'operation_id': operation_id, 'state': state}
        try:
            outcome = self.target.apply(operation_id, request_hash, artifact, lose_response=lose_response)
        except UncertainOutcome:
            self._state(operation_id, 'UNCERTAIN', None)
            return {'operation_id': operation_id, 'state': 'UNCERTAIN'}
        except Exception:
            self._state(operation_id, 'UNCERTAIN', None)
            raise
        self._state(operation_id, 'SUCCEEDED', outcome)
        return {'operation_id': operation_id, 'state': 'SUCCEEDED', 'result': outcome}

    def reconcile(self, operation_id: str) -> dict:
        row = self._row(operation_id)
        if row is None:
            raise DeploymentError('unknown operation')
        request_hash, artifact, state, _ = row
        if state == 'SUCCEEDED':
            return {'operation_id': operation_id, 'state': state}
        observed = self.target.inspect(operation_id)
        if observed is not None:
            if observed != {'request_hash': request_hash, 'artifact': artifact}:
                raise DeploymentError('target record conflicts with authorization')
            self._state(operation_id, 'SUCCEEDED', 'reconciled')
            return {'operation_id': operation_id, 'state': 'SUCCEEDED', 'result': 'reconciled'}
        # This is a controlled retry using the stored authorized request, NOT
        # reauthorization of an arbitrary caller-supplied operation.
        return self._execute(operation_id)

    def _row(self, op_id):
        with closing_db(self.path) as db:
            return db.execute('SELECT request_hash, artifact, state, target_result FROM deployments WHERE operation_id=?', (op_id,)).fetchone()

    def _state(self, op_id, state, outcome):
        with closing_db(self.path) as db:
            db.execute('UPDATE deployments SET state=?, target_result=? WHERE operation_id=?', (state, outcome, op_id))


class AtomicDeploymentEngine(DeploymentEngine):
    """Local SQLite atomic authorization+intent record. No external atomic side effects.

    Both tables MUST live in the same SQLite database file. This is intentionally
    a distinct API from the historical non-atomic DeploymentEngine.
    """
    def __init__(self, path: str | Path, release_gate: ReleaseGate, target: MockDeploymentTarget):
        if Path(path).resolve() != Path(release_gate.path).resolve():
            raise ValueError('release gate and deployment ledger must use one database')
        super().__init__(path, release_gate, target)

    def submit(self, intent: ReleaseIntent, signature: str, actual_artifact_sha256: str,
               *, lose_response: bool = False, fail_before_commit: bool = False) -> dict:
        decision = self.gate.validate_intent(intent, signature, actual_artifact_sha256=actual_artifact_sha256)
        op_id = self.operation_id(intent)
        with closing_db(self.path, timeout=5, isolation_level=None) as db:
            db.execute('BEGIN IMMEDIATE')
            # Re-check time and policy after waiting for SQLite writer lock.
            decision = self.gate.validate_intent(intent, signature, actual_artifact_sha256=actual_artifact_sha256)
            self.gate.consume_in_transaction(db, intent, decision)
            db.execute('INSERT INTO deployments VALUES (?, ?, ?, ?, NULL)',
                       (op_id, decision['intent_sha256'], actual_artifact_sha256, 'PENDING'))
            if fail_before_commit:
                raise DeploymentError('injected crash before commit')
            db.execute('COMMIT')
        return self._execute(op_id, lose_response=lose_response)
