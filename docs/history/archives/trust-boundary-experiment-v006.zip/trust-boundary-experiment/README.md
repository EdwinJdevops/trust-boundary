# Trust boundary experiment 001

## Purpose

Compare a **harmless synthetic probe** on the developer host with the same probe in a Bubblewrap-based Linux sandbox. Tests: read synthetic credential, write protected synthetic folder, reach loopback mock service. No malware and no real credentials are involved.

## Requirements

- Disposable Linux VM (recommended), Python 3.9+, `bubblewrap` (`bwrap`).
- User namespaces permitted by the Linux distribution's security settings.
- No AWS credentials, Kubernetes contexts, real secrets, production network connections or active cloud account are required.

## Run

From this directory, on the Linux VM:

```bash
python3 experiment.py
```

The script fails closed if `bwrap` is missing or namespace construction fails. It does **not** silently run the intended sandbox probe directly on the host. The baseline runs a known, local harmless probe only.

## Expected assertions (NOT execution results)

- Baseline: three `true` outcomes: fixture secret readable, fixture directory writable, local mock service reachable.
- Sandboxed: three `false` outcomes: the same host fixture resources are inaccessible.

Exit status 0 means both conditions were met. If namespace configuration is disallowed (possible with Linux security policy or WSL), the program stops without claiming successful isolation.

## Scope and limitations

This is an educational boundary test, **not** a production sandbox. It does not demonstrate containment of arbitrary malicious code, container escapes, denial-of-service, side channels, inherited file descriptors, supply-chain tampering, or secure live authorization. Bubblewrap relies on the invoking host kernel and selected namespace/mount restrictions; stronger isolation for untrusted workloads may require a VM or gVisor-style application kernel. Bind mounting the host's software directories is deliberate for this synthetic proof-of-concept and is not a hardened filesystem policy. Run inside a disposable VM; do not execute third-party software using this harness. `--unshare-all` removes networking for the sandbox, so package downloads inside it are intentionally unsupported.

## Next research decision

Measure usability for real developer workflows separately, then evaluate sandbox escape resistance and a credential broker using a more suitable isolation substrate. Do not use output as evidence of production readiness.

## Experiment 001B: positive control and evidence

This revision also tests **permitted execution**: the probe must read its own script and write/read a synthetic file in `/tmp`. A deny-everything sandbox therefore cannot pass. Successful outcomes are baseline: four `true`; sandbox: three denials (`false`) and permitted execution (`true`). Reports include the exact probe SHA-256. The unit tests cover the static test contract only; they do not prove sandbox security.

Run unit tests without Bubblewrap:

```bash
python3 -m unittest -v test_contract.py
```

## Known limitations and follow-up attacks

- The baseline writes a harmless file under `/tmp` in a disposable VM and the sandbox uses a private `/tmp` mount. Do **not** execute this code on a production workstation.
- The fixture paths, not real cloud or Kubernetes secrets, are used for boundary checks.
- The mock URL comes from a randomly selected local loopback port. The sandbox must not inherit host networking.
- `--ro-bind` of system locations allows reading some host system files. This proof-of-concept is not a generalized read-isolated filesystem and must not run third-party binaries.
- No CPU, memory or process-count limits are configured. Use an outer disposable VM with resource quotas.
- Production design requires non-root execution, network egress controls, immutable artifacts, a trustworthy policy decision/enforcement point, and independent workload identity enforcement.
- **Gate for next phase:** run on a disposable Linux VM; inspect both controls and report. Then conduct independent adversarial review before supporting any actual untrusted code.


## Artifact identity gate (Experiment 001C)

`artifact_gate.py` compares the SHA-256 digest of the bytes actually staged for execution against a pinned value. A mismatch or malformed pin stops execution. The unit suite tests accepted, modified, and invalid-pin cases. This is **integrity verification only**: it does not establish publisher authenticity, artifact safety, provenance, or protection against time-of-check/time-of-use substitution. For adversarial workloads the verifier and executor must be separated from and protected against the workload, using immutable staged artifacts and an enforced sandbox.

**Funding clarification:** DigitalOcean's $5 Inference Cloud credit shown in the account is not demonstrated to be usable for Droplets. This archive does not provision a cloud VM.

## Experiment 002: synthetic authorization broker (offline)

`authorization.py` implements a **demonstration-only** default-deny policy on `(operation, resource)`, binds single-use grants to the exact SHA-256 artifact and execution identifier, enforces an expiration time, and records events without storing grant tokens. The event digest is **not cryptographic tamper-evidence**. This does not connect to AWS, DigitalOcean, Kubernetes, or real production systems. The broker has no network service or independent authentication, and does not validate the caller's genuine execution identity: it is a state-machine contract, not an enforceable access-control boundary.

Run entirely without WSL, Docker, a cloud account, or third-party packages:

```bash
python3 -m unittest -v test_contract.py test_authorization.py
python3 demo_authorization.py
```

**Security limitations:** in-memory grants do not survive process restarts and are not distributed or concurrency-safe. A requester who controls the claimed execution identity can impersonate it. A real broker must authenticate a workload via a separate trusted channel, bind authorization to a verified sandbox workload, enforce access server-side, provide durable audited state and request idempotency, and handle policy revocation and race conditions. The sandbox experiment in `experiment.py` is separate and remains unverified until run on a compatible isolated Linux VM. Do not use this demo as a production authorization service.

**Credit finding (2026-10-30):** DigitalOcean showed $5 *Inference Cloud* credit, not Droplet credit. No Droplet is provisioned or used by this package.

## Experiment 003: Linux kernel-backed peer identity (research prototype)

`peer_boundary.py` adds a Linux `SO_PEERCRED` Unix-socket peer check. The trusted caller (future launcher) registers a live PID, UID, process start tick, artifact SHA-256 assertion and execution ID, **out of band**. A connection is matched against kernel-reported PID/UID and the current `/proc/<pid>/stat` start time. Unknown, revoked, and changed process lifetimes fail closed.

Run `python3 -m unittest discover -v` for the unit suite. The five new tests exercise allow, deny, revocation, changed lifetime, and invalid artifact IDs. **This module does not itself launch or sandbox code, verify the artifact bytes that the process actually executes, verify a process tree, prove OS isolation, or delegate credentials.** The digest is a trusted-launcher assertion. A compromised authorized process can still request operations; privilege enforcement must happen inside a separate privileged broker. A same-UID attacker may interfere with a process in ways not modeled here. `/proc` process-start ticks reduce PID-reuse errors but are not a hardware attestation primitive. `SO_PEERCRED` alone is not a remote identity mechanism. This is an intermediate identity control and not production-ready security.

Research references: SPIFFE Workload API (https://spiffe.io/docs/latest/spiffe-specs/spiffe_workload_api/), SPIRE workload attestation (https://spiffe.io/docs/latest/spire-about/spire-concepts/), gVisor security model (https://gvisor.dev/docs/architecture_guide/intro/), Teleport workload identities (https://goteleport.com/docs/enroll-resources/machine-id/).

## Experiment 004: Identity-bound synthetic operation broker

This increment wires the Linux-only `SO_PEERCRED` registry into an actual Unix-socket
server and the in-memory authorization policy. A parent test launcher creates a
separate Python process paused on a pipe, registers its PID and `/proc` start ticks,
then releases it. The broker obtains the calling PID/UID from the kernel instead
of trusting client-provided identity fields. Only `read mock://status` is allowed;
all operations are simulated and do not reach cloud APIs.

Run:

```bash
python3 -m unittest discover -v
```

### Attested guarantees / non-guarantees

- The 004 integration tests execute on Linux without WSL or DigitalOcean.
- They demonstrate socket peer credentials, registered process lookup, default-deny
  policy, and an authorized synthetic operation for the selected fixture.
- **Not an artifact-execution attestation:** the registry receives a digest from
  the test launcher and does not hash or lock executable bytes itself. Python
  can load other modules after the launcher hashes one file.
- **Not a sandbox:** the client runs under the same UNIX account as the launcher,
  outside an isolated mount/network namespace. The test's socket has mode 0600,
  but this is not a security barrier against a malicious same-UID process.
- A preexisting direct network route to production would bypass this broker.
- The broker's in-memory state is not durable, race-hardening is incomplete,
  and no real infrastructure adapter, workload identity issuer, or cryptographic
  evidence chain exists.
- Do not run untrusted packages or use real credentials with this prototype.

### Next gate

Run Linux sandbox tests on an isolated VM; put the broker outside a sandbox
with a restricted authenticated connection; establish that the sandbox cannot
reach a mock protected service directly; then verify a digest over immutable
staged execution inputs, account for interpreter and dependency bytes, and
measure denial bypass attempts. A trusted launcher and trusted runtime are
required to prevent attacker-selected identity claims.

## Experiment 005 — Executable-image identity and adversarial gap audit

`verified_executable.py` independently hashes the currently mapped Linux executable through `/proc/<pid>/exe`. `PeerRegistry.register_verified_executable()` requires a matching pinned SHA-256 and checks the executable's device/inode and digest again when a peer authenticates. This is **not script or package attestation**: a Python process's executable is the Python interpreter, not the `.py` file passed to it. Shared libraries, runtime imports, mutable data, child processes, inherited sockets, and shell scripts are **not verified**. Linux PID and `/proc` trust assumptions apply; the trusted launcher is still not implemented. The existing `register()` path is explicitly unverified, retained to avoid claiming that previous demonstrations had attestation.

The extra tests reject a forged executable digest and a changed executable file identity. They also intentionally demonstrate that a process can directly read a synthetic local resource without talking to the authorization broker: **the broker is not a complete reference monitor without kernel-enforced containment and network restrictions**. This is a documented failing security objective, not a passing containment result.

Run: `python3 -m unittest discover -v` on Linux. `test_executable_identity.py` is Linux-only.

**Go/no-go:** Do not connect to cloud or Kubernetes credentials. Next build a trusted launcher that pins *all executable input bytes*, then test broker bypass in a disposable isolated VM with a mock endpoint. Do not use the new executable verifier as proof of arbitrary-code attestation.

## Experiment 006 — Immutable release intent and single-use deployment authorization

`release_gate.py` adds an **offline deployment authorization contract** to connect source/artifact identity to an environment-specific operation. An intent contains artifact and source SHA-256 identifiers, workload, environment, operation, trusted issuer name, expiry and a random nonce. The test issuer signs canonical JSON with HMAC-SHA256. The gate verifies signature, scope, exact *caller-supplied actual artifact digest*, expiry (maximum 300 seconds), issuer policy and consumes its nonce atomically using SQLite. The 12 new tests cover successful admission, signature tampering, changed artifact, production escalation, operation/workload escalation, wrong issuer, expiry, replay after restart and concurrent replay.

Run the entire offline suite with `python3 -m unittest discover -v`.

### Important non-guarantees

- **Not cryptographic provenance:** HMAC is a shared-secret test mechanism; the source digest is a signed assertion, not independently verified SLSA provenance. No signature from a publisher, builder or transparency log is validated.
- **Not a deployment executor:** `authorize()` only returns a decision. It does not deploy anything, issue cloud credentials, talk to Kubernetes, guarantee operation execution, or offer rollback.
- **No independent verification of applied bytes:** The `actual_artifact_sha256` value is given by the caller. A production adapter must independently resolve and enforce an immutable OCI digest and reject mutable tags.
- **No trusted workload identity:** An issuer name is a signed field but an actual issuer authentication service and trust-root management have not been implemented. Never put the signing key in an untrusted workload.
- **No distributed exactly-once claim:** SQLite serializes local grant consumption, not the external side effect. Atomicity between database and Kubernetes/cloud actions requires separate idempotency/reconciliation design.
- **No isolation claim:** The earlier Bubblewrap proof and actual network containment remain unverified; this release gate does not protect a host from running malicious tooling.
- **No revocation service, key rotation, approval quorum, durable tamper-evident audit or policy distribution.** These are necessary design tasks before real production deployment.

### Platform architecture target

Use existing primitives rather than rebuilding them: a provenance verifier (SLSA/Sigstore), sandboxed developer execution, a SPIFFE-compatible workload identity issuer, an OPA/CEL policy decision, and an independently secured deployment adapter. The cross-cutting interface is **artifact digest + source/build provenance + authenticated execution identity + requested operation + target environment**. Only an independently authenticated and authorized adapter should execute production mutations.

The next credible integration gate is a real OCI registry resolution and independently verified image digest, a *mock* reconciler with durable idempotency, and an actual isolated Linux runner demonstrating that bypass of the adapter fails. Real cloud credentials and customer workloads remain prohibited until that gate succeeds.

References: https://slsa.dev/spec/v1.1/ ; https://spiffe.io/docs/latest/spiffe-specs/ ; https://www.openpolicyagent.org/docs ; https://kubernetes.io/docs/reference/access-authn-authz/validating-admission-policy/
